//
// Created by Huai-Che Lu on 2/28/17.
//

#ifndef CS5450_LAB1_REQUEST_HANDLER_H
#define CS5450_LAB1_REQUEST_HANDLER_H

typedef struct Request Request;
typedef struct Response Response;

Response *handle_request(Request *request);

#endif //CS5450_LAB1_REQUEST_HANDLER_H
