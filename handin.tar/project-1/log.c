


FILE *server_log; //https://stackoverflow.com/questions/23856306/how-to-create-log-file-in-c

